<?php

use App\Models\ChatRoom;
use App\Models\User;
use Illuminate\Support\Facades\Broadcast;

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Channels named "chat-room.{id}" — only users who are members of the room
| can subscribe.
|
*/

Broadcast::channel('chat-room.{roomId}', function (User $user, int $roomId) {
    $room = ChatRoom::find($roomId);
    if (!$room) return false;

    // Admins can subscribe to any room
    if ($user->isAdmin()) {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'avatar' => $user->avatar_url,
        ];
    }

    // Members can subscribe
    $isMember = $room->users()->where('users.id', $user->id)->exists();
    if (!$isMember) return false;

    return [
        'id' => $user->id,
        'name' => $user->name,
        'avatar' => $user->avatar_url,
    ];
});

// Presence channel for online status
Broadcast::channel('presence.users', function (User $user) {
    return [
        'id' => $user->id,
        'name' => $user->name,
        'avatar' => $user->avatar_url,
        'role' => $user->role,
    ];
});
