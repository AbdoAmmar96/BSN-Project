<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class AuthController extends Controller
{
    /**
     * Register a new user (public — role defaults to 'user').
     */
    public function register(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => 'required|string|min:2|max:120',
            'email' => 'required|email|max:255|unique:users,email',
            'password' => ['required', 'confirmed', Password::min(8)],
            'phone' => 'nullable|string|max:20',
            'company' => 'nullable|string|max:120',
        ]);

        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => $data['password'],
            'role' => User::ROLE_USER,
            'phone' => $data['phone'] ?? null,
            'company' => $data['company'] ?? null,
        ]);

        $token = $user->createToken('web', expiresAt: now()->addDays(30))->plainTextToken;

        return response()->json([
            'message' => 'تم التسجيل بنجاح',
            'user' => $user,
            'token' => $token,
        ], 201);
    }

    /**
     * Login with email + password.
     */
    public function login(Request $request): JsonResponse
    {
        $data = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
            'device_name' => 'nullable|string|max:60',
        ]);

        $user = User::where('email', $data['email'])->first();

        if (!$user || !Hash::check($data['password'], $user->password)) {
            return response()->json([
                'message' => 'البريد أو كلمة المرور غير صحيحة',
            ], 422);
        }

        if (!$user->is_active) {
            return response()->json([
                'message' => 'الحساب موقوف. تواصل مع الدعم.',
            ], 403);
        }

        $deviceName = $data['device_name'] ?? $request->userAgent() ?? 'web';
        $token = $user->createToken($deviceName, expiresAt: now()->addDays(30))->plainTextToken;

        $user->update(['last_seen_at' => now()]);

        return response()->json([
            'message' => 'تم تسجيل الدخول',
            'user' => $user,
            'token' => $token,
        ]);
    }

    /**
     * Get currently authenticated user.
     */
    public function me(Request $request): JsonResponse
    {
        return response()->json([
            'user' => $request->user()->load([]),
        ]);
    }

    /**
     * Logout current device.
     */
    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'تم تسجيل الخروج']);
    }

    /**
     * Logout all devices.
     */
    public function logoutAll(Request $request): JsonResponse
    {
        $request->user()->tokens()->delete();
        return response()->json(['message' => 'تم تسجيل الخروج من كل الأجهزة']);
    }

    /**
     * Update profile.
     */
    public function updateProfile(Request $request): JsonResponse
    {
        $user = $request->user();
        $data = $request->validate([
            'name' => 'sometimes|string|min:2|max:120',
            'phone' => 'sometimes|nullable|string|max:20',
            'company' => 'sometimes|nullable|string|max:120',
            'position' => 'sometimes|nullable|string|max:120',
            'bio' => 'sometimes|nullable|string|max:1000',
            'skills' => 'sometimes|nullable|array',
            'locale' => 'sometimes|in:ar,en',
        ]);

        $user->update($data);

        return response()->json([
            'message' => 'تم تحديث الملف الشخصي',
            'user' => $user->fresh(),
        ]);
    }

    /**
     * Change password.
     */
    public function changePassword(Request $request): JsonResponse
    {
        $data = $request->validate([
            'current_password' => 'required|string',
            'password' => ['required', 'confirmed', Password::min(8)],
        ]);

        $user = $request->user();

        if (!Hash::check($data['current_password'], $user->password)) {
            return response()->json(['message' => 'كلمة المرور الحالية غير صحيحة'], 422);
        }

        $user->update(['password' => $data['password']]);

        return response()->json(['message' => 'تم تغيير كلمة المرور']);
    }
}
