<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Project;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    /**
     * GET /api/invoices — scoped by role.
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();
        $query = Invoice::with(['project:id,title,slug', 'user:id,name,email,company'])
            ->withCount('payments')
            ->latest();

        if (!$user->isAdmin()) {
            $query->where('user_id', $user->id);
        }

        if ($status = $request->query('status')) {
            $query->where('status', $status);
        }

        return response()->json(['data' => $query->paginate(20)]);
    }

    /**
     * POST /api/invoices — admin only.
     */
    public function store(Request $request): JsonResponse
    {
        if (!$request->user()->isAdmin()) abort(403);

        $data = $request->validate([
            'project_id' => 'required|exists:projects,id',
            'user_id' => 'required|exists:users,id',
            'items' => 'required|array|min:1',
            'items.*.description' => 'required|string|max:255',
            'items.*.quantity' => 'required|numeric|min:1',
            'items.*.price' => 'required|numeric|min:0',
            'tax' => 'nullable|numeric|min:0',
            'discount' => 'nullable|numeric|min:0',
            'currency' => 'nullable|string|size:3',
            'issued_at' => 'nullable|date',
            'due_at' => 'nullable|date|after_or_equal:issued_at',
            'notes' => 'nullable|string|max:2000',
        ]);

        $subtotal = collect($data['items'])->sum(fn($i) => $i['quantity'] * $i['price']);
        $total = $subtotal + ($data['tax'] ?? 0) - ($data['discount'] ?? 0);

        $invoice = Invoice::create([
            ...$data,
            'subtotal' => $subtotal,
            'tax' => $data['tax'] ?? 0,
            'discount' => $data['discount'] ?? 0,
            'total' => $total,
            'currency' => $data['currency'] ?? 'EGP',
            'status' => 'draft',
        ]);

        return response()->json([
            'message' => 'تم إنشاء الفاتورة',
            'invoice' => $invoice->load(['project', 'user']),
        ], 201);
    }

    public function show(Request $request, Invoice $invoice): JsonResponse
    {
        $user = $request->user();
        if (!$user->isAdmin() && $invoice->user_id !== $user->id) abort(403);

        $invoice->load(['project', 'user', 'payments']);
        return response()->json(['invoice' => $invoice]);
    }

    /**
     * PUT /api/invoices/{invoice} — update status (admin only).
     */
    public function update(Request $request, Invoice $invoice): JsonResponse
    {
        if (!$request->user()->isAdmin()) abort(403);

        $data = $request->validate([
            'status' => 'sometimes|in:draft,sent,partial,paid,overdue,cancelled',
            'notes' => 'sometimes|nullable|string|max:2000',
            'due_at' => 'sometimes|nullable|date',
        ]);

        $invoice->update($data);
        return response()->json(['message' => 'تم التحديث', 'invoice' => $invoice]);
    }

    public function destroy(Request $request, Invoice $invoice): JsonResponse
    {
        if (!$request->user()->isAdmin()) abort(403);
        $invoice->delete();
        return response()->json(['message' => 'تم الحذف']);
    }

    /**
     * GET /api/admin/overview-stats — top-level dashboard stats.
     */
    public function overviewStats(Request $request): JsonResponse
    {
        if (!$request->user()->isAdmin()) abort(403);

        return response()->json([
            'users' => [
                'total' => User::count(),
                'new_this_month' => User::where('created_at', '>=', now()->startOfMonth())->count(),
                'by_role' => [
                    'admin' => User::where('role', 'admin')->count(),
                    'developer' => User::where('role', 'developer')->count(),
                    'user' => User::where('role', 'user')->count(),
                ],
            ],
            'projects' => [
                'total' => Project::count(),
                'in_progress' => Project::where('status', 'in_progress')->count(),
                'completed' => Project::where('status', 'completed')->count(),
                'pending' => Project::where('status', 'pending')->count(),
            ],
            'revenue' => [
                'total' => \App\Models\Payment::where('status', 'completed')->sum('amount'),
                'this_month' => \App\Models\Payment::where('status', 'completed')
                    ->where('paid_at', '>=', now()->startOfMonth())->sum('amount'),
                'pending' => Invoice::whereIn('status', ['sent', 'partial', 'overdue'])->sum('total'),
            ],
        ]);
    }
}
