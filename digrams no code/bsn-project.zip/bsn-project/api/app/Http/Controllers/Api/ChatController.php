<?php

namespace App\Http\Controllers\Api;

use App\Events\MessageSent;
use App\Events\UserTyping;
use App\Http\Controllers\Controller;
use App\Models\ChatRoom;
use App\Models\Message;
use App\Models\MessageRead;
use App\Models\Project;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    /**
     * GET /api/chat/rooms — list rooms the user belongs to.
     */
    public function rooms(Request $request): JsonResponse
    {
        $user = $request->user();

        $rooms = $user->chatRooms()
            ->with([
                'project:id,title,slug,service_type',
                'lastMessage.sender:id,name,avatar',
                'users:id,name,avatar,role',
            ])
            ->orderByDesc('last_message_at')
            ->get()
            ->map(function (ChatRoom $room) use ($user) {
                return [
                    'id' => $room->id,
                    'name' => $this->roomDisplayName($room, $user),
                    'type' => $room->type,
                    'avatar' => $this->roomDisplayAvatar($room, $user),
                    'project' => $room->project,
                    'last_message' => $room->lastMessage ? [
                        'body' => $room->lastMessage->body,
                        'type' => $room->lastMessage->type,
                        'sender_name' => $room->lastMessage->sender?->name,
                        'created_at' => $room->lastMessage->created_at?->toIso8601String(),
                    ] : null,
                    'unread_count' => $room->unreadCountForUser($user->id),
                    'members_count' => $room->users()->count(),
                    'updated_at' => $room->last_message_at?->toIso8601String() ?? $room->updated_at->toIso8601String(),
                ];
            });

        return response()->json(['data' => $rooms]);
    }

    /**
     * GET /api/chat/rooms/{room} — single room with recent messages.
     */
    public function show(Request $request, ChatRoom $room): JsonResponse
    {
        $this->authorize($request->user(), $room);

        $messages = $room->messages()
            ->with('sender:id,name,avatar', 'replyTo.sender:id,name,avatar')
            ->latest()
            ->limit(50)
            ->get()
            ->reverse()
            ->values();

        // Mark room as read
        $room->users()->updateExistingPivot($request->user()->id, [
            'last_read_at' => now(),
        ]);

        return response()->json([
            'room' => $room->load([
                'project:id,title,slug,service_type',
                'users:id,name,avatar,role',
            ]),
            'messages' => $messages,
        ]);
    }

    /**
     * POST /api/chat/rooms/project/{project} — get or create project's room.
     */
    public function projectRoom(Request $request, Project $project): JsonResponse
    {
        $user = $request->user();

        // Authorize access to project
        $hasAccess = $user->isAdmin()
            || $project->client_id === $user->id
            || $project->lead_developer_id === $user->id
            || $project->members()->where('user_id', $user->id)->exists();
        if (!$hasAccess) abort(403);

        $room = ChatRoom::firstOrCreate(
            ['project_id' => $project->id, 'type' => 'project'],
            [
                'name' => $project->title,
                'created_by' => $user->id,
                'last_message_at' => now(),
            ]
        );

        // Sync members: client + lead developer + project members
        $memberIds = collect([$project->client_id, $project->lead_developer_id])
            ->filter()
            ->concat($project->members()->pluck('user_id'))
            ->unique()
            ->values()
            ->all();

        foreach ($memberIds as $uid) {
            $room->users()->syncWithoutDetaching([
                $uid => ['role' => 'member', 'joined_at' => now()],
            ]);
        }

        return response()->json([
            'room' => $room->load([
                'project:id,title,slug,service_type',
                'users:id,name,avatar,role',
            ]),
        ]);
    }

    /**
     * POST /api/chat/rooms/direct/{user} — get or create direct room with another user.
     */
    public function directRoom(Request $request, User $other): JsonResponse
    {
        $user = $request->user();

        if ($user->id === $other->id) {
            return response()->json(['message' => 'لا تقدر تكلم نفسك'], 422);
        }

        // Find room where both users are members and type=direct
        $room = ChatRoom::query()
            ->where('type', 'direct')
            ->whereNull('project_id')
            ->whereHas('users', fn($q) => $q->where('users.id', $user->id))
            ->whereHas('users', fn($q) => $q->where('users.id', $other->id))
            ->first();

        if (!$room) {
            $room = ChatRoom::create([
                'type' => 'direct',
                'created_by' => $user->id,
                'last_message_at' => now(),
            ]);
            $room->users()->attach([
                $user->id => ['role' => 'member', 'joined_at' => now()],
                $other->id => ['role' => 'member', 'joined_at' => now()],
            ]);
        }

        return response()->json([
            'room' => $room->load('users:id,name,avatar,role'),
        ]);
    }

    /**
     * GET /api/chat/rooms/{room}/messages — paginated message history.
     */
    public function messages(Request $request, ChatRoom $room): JsonResponse
    {
        $this->authorize($request->user(), $room);

        $query = $room->messages()
            ->with('sender:id,name,avatar', 'replyTo.sender:id,name,avatar')
            ->latest();

        // Load older messages via 'before' param (cursor)
        if ($before = $request->query('before_id')) {
            $query->where('id', '<', $before);
        }

        $messages = $query->limit(30)->get()->reverse()->values();

        return response()->json([
            'data' => $messages,
            'has_more' => $messages->count() === 30,
        ]);
    }

    /**
     * POST /api/chat/rooms/{room}/messages — send a message.
     */
    public function send(Request $request, ChatRoom $room): JsonResponse
    {
        $this->authorize($request->user(), $room);

        $data = $request->validate([
            'body' => 'required_without:attachment|nullable|string|max:5000',
            'reply_to_id' => 'nullable|exists:messages,id',
            'attachment' => 'nullable|file|max:10240', // 10MB
        ]);

        $messageData = [
            'user_id' => $request->user()->id,
            'reply_to_id' => $data['reply_to_id'] ?? null,
            'body' => $data['body'] ?? null,
            'type' => 'text',
        ];

        if ($request->hasFile('attachment')) {
            $file = $request->file('attachment');
            $path = $file->store("chat/{$room->id}", 'public');
            $messageData['attachment_path'] = $path;
            $messageData['attachment_name'] = $file->getClientOriginalName();
            $messageData['attachment_mime'] = $file->getMimeType();
            $messageData['attachment_size'] = $file->getSize();
            $messageData['type'] = str_starts_with($file->getMimeType(), 'image/') ? 'image' : 'file';
        }

        $message = $room->messages()->create($messageData);

        // Update room's last activity
        $room->update(['last_message_at' => now()]);

        // Mark sender's own message as read
        $room->users()->updateExistingPivot($request->user()->id, ['last_read_at' => now()]);

        // Broadcast
        broadcast(new MessageSent($message))->toOthers();

        return response()->json([
            'message' => $message->load('sender:id,name,avatar'),
        ], 201);
    }

    /**
     * POST /api/chat/rooms/{room}/read — mark room as read.
     */
    public function markRead(Request $request, ChatRoom $room): JsonResponse
    {
        $this->authorize($request->user(), $room);
        $room->users()->updateExistingPivot($request->user()->id, ['last_read_at' => now()]);
        return response()->json(['ok' => true]);
    }

    /**
     * POST /api/chat/rooms/{room}/typing — broadcast typing event.
     */
    public function typing(Request $request, ChatRoom $room): JsonResponse
    {
        $this->authorize($request->user(), $room);
        $isTyping = (bool) $request->input('is_typing', true);
        broadcast(new UserTyping($room->id, $request->user(), $isTyping))->toOthers();
        return response()->json(['ok' => true]);
    }

    /**
     * DELETE /api/chat/messages/{message} — delete own message.
     */
    public function deleteMessage(Request $request, Message $message): JsonResponse
    {
        if ($message->user_id !== $request->user()->id && !$request->user()->isAdmin()) {
            abort(403);
        }
        $message->delete();
        return response()->json(['ok' => true]);
    }

    // ============================================
    // Helpers
    // ============================================
    protected function authorize(User $user, ChatRoom $room): void
    {
        if ($user->isAdmin()) return;
        $isMember = $room->users()->where('users.id', $user->id)->exists();
        if (!$isMember) abort(403, 'مش عضو في المحادثة دي');
    }

    protected function roomDisplayName(ChatRoom $room, User $user): string
    {
        if ($room->type === 'project') return $room->project?->title ?? $room->name ?? 'مشروع';
        if ($room->type === 'direct') {
            $other = $room->users->where('id', '!=', $user->id)->first();
            return $other?->name ?? 'محادثة';
        }
        return $room->name ?? 'محادثة';
    }

    protected function roomDisplayAvatar(ChatRoom $room, User $user): ?string
    {
        if ($room->type === 'direct') {
            $other = $room->users->where('id', '!=', $user->id)->first();
            return $other?->avatar;
        }
        return null;
    }
}
