import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import { paymentsApi } from '@/api/payments';
import GatewaySelector from './GatewaySelector';
import Modal from '@/components/dashboard/Modal';
import { CreditCard, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';

/**
 * Reusable Pay button — opens a modal with gateway selector,
 * initiates payment, then routes to the right next step.
 *
 * Props:
 *   amount:       number
 *   currency:     string  (default 'EGP')
 *   invoiceId:    optional — links payment to an invoice
 *   projectId:    optional — links payment to a project
 *   label:        string  (default "ادفع دلوقتي")
 *   className:    optional css for the button
 */
export default function PayButton({ amount, currency = 'EGP', invoiceId, projectId, label = 'ادفع دلوقتي', className }) {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [gateway, setGateway] = useState('');
  const [phone, setPhone] = useState('');
  const [months, setMonths] = useState(6);

  const initiate = useMutation({
    mutationFn: () => paymentsApi.initiate({
      gateway,
      amount,
      currency,
      invoice_id: invoiceId,
      project_id: projectId,
      phone: gateway === 'paymob_wallet' ? phone : undefined,
      months: gateway === 'paymob_installments' ? months : undefined,
    }),
    onSuccess: ({ payment, checkout }) => {
      setOpen(false);

      if (checkout.type === 'redirect') {
        // Paymob wallet / installments / Kashier — open gateway URL
        toast.success('بنحوّلك للدفع...');
        window.location.href = checkout.data.redirect_url;
      } else if (checkout.type === 'iframe' || checkout.type === 'reference') {
        // Paymob card → iframe page · Fawry → reference page
        navigate(`/payment/checkout/${payment.id}`);
      }
    },
    onError: (err) => {
      const msg = err.response?.data?.message || err.response?.data?.error || 'فشل بدء الدفع';
      toast.error(msg);
    },
  });

  const canSubmit = gateway && (gateway !== 'paymob_wallet' || phone.length >= 10);

  return (
    <>
      <button onClick={() => setOpen(true)} className={className || 'btn-primary'}>
        <CreditCard size={16} /> {label}
      </button>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="طرق الدفع المتاحة"
        size="lg"
        footer={
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="text-sm">
              <span className="opacity-60">المبلغ المطلوب: </span>
              <span className="font-display font-black text-xl text-brand-orange">
                {Number(amount).toLocaleString()} {currency}
              </span>
            </div>
            <div className="flex gap-2">
              <button onClick={() => setOpen(false)} className="btn-ghost text-sm">إلغاء</button>
              <button
                onClick={() => initiate.mutate()}
                disabled={!canSubmit || initiate.isPending}
                className="btn-primary text-sm disabled:opacity-60"
              >
                {initiate.isPending ? 'جاري...' : 'ابدأ الدفع'} <ArrowLeft size={14} />
              </button>
            </div>
          </div>
        }
      >
        <GatewaySelector
          amount={amount}
          selected={gateway}
          onSelect={setGateway}
          phone={phone}
          onPhoneChange={setPhone}
          months={months}
          onMonthsChange={setMonths}
        />
      </Modal>
    </>
  );
}
