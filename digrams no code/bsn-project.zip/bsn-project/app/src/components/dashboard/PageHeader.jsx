import { Link } from 'react-router-dom';

/**
 * Consistent page header for dashboard pages.
 *
 * Props:
 *   eyebrow:     "USERS / PROJECTS / ..."
 *   title:       "إدارة المستخدمين"
 *   description: optional sub-text
 *   action:      ReactNode  (usually a button: "+ مستخدم جديد")
 *   backTo:      optional path to go back
 */
export default function PageHeader({ eyebrow, title, description, action, backTo }) {
  return (
    <div className="mb-6">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          {backTo && (
            <Link to={backTo} className="text-xs font-mono opacity-60 hover:text-brand-orange transition">
              ← رجوع
            </Link>
          )}
          {eyebrow && (
            <span className="block font-mono text-xs tracking-widest text-brand-orange opacity-80 mt-1">
              — {eyebrow}
            </span>
          )}
          <h1 className="font-display font-black text-2xl md:text-3xl mt-1">{title}</h1>
          {description && <p className="text-sm opacity-70 mt-1">{description}</p>}
        </div>
        {action}
      </div>
    </div>
  );
}
