import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import ProtectedRoute from '@/components/ProtectedRoute';

// Public
import PublicLayout from '@/layouts/PublicLayout';
import Home from '@/pages/public/Home';
import Services from '@/pages/public/Services';
import Pricing from '@/pages/public/Pricing';
import Portfolio from '@/pages/public/Portfolio';
import About from '@/pages/public/About';
import Contact from '@/pages/public/Contact';
import ServiceDetail from '@/pages/public/ServiceDetail';

// Auth
import Login from '@/pages/auth/Login';
import Register from '@/pages/auth/Register';

// Payment
import PaymentCheckout from '@/pages/payment/Checkout';
import PaymentSuccess from '@/pages/payment/Success';
import PaymentFailure from '@/pages/payment/Failure';
import PaymentReturn from '@/pages/payment/Return';

// Chat (shared across all roles)
import ChatPage from '@/pages/chat/ChatPage';

// Dashboard layout
import DashboardLayout from '@/layouts/DashboardLayout';

// Admin
import AdminDashboard from '@/dashboards/admin/AdminDashboard';
import UsersList from '@/dashboards/admin/UsersList';
import UserForm from '@/dashboards/admin/UserForm';
import ProjectsList from '@/dashboards/admin/ProjectsList';
import ProjectForm from '@/dashboards/admin/ProjectForm';
import AdminPaymentsList from '@/dashboards/admin/AdminPaymentsList';
import AdminInvoicesList from '@/dashboards/admin/AdminInvoicesList';
import InvoiceForm from '@/dashboards/admin/InvoiceForm';

// Developer
import DeveloperDashboard from '@/dashboards/developer/DeveloperDashboard';
import DevProjectsList from '@/dashboards/developer/DevProjectsList';
import TasksKanban from '@/dashboards/developer/TasksKanban';

// User
import UserDashboard from '@/dashboards/user/UserDashboard';
import UserProjectsList from '@/dashboards/user/UserProjectsList';
import UserNewProject from '@/dashboards/user/UserNewProject';
import UserInvoicesList from '@/dashboards/user/UserInvoicesList';
import UserPaymentsList from '@/dashboards/user/UserPaymentsList';

// Shared
import ProjectDetail from '@/dashboards/shared/ProjectDetail';
import Profile from '@/dashboards/shared/Profile';

export default function App() {
  const { user } = useAuth();

  const defaultDashboard = user
    ? user.role === 'admin' ? '/admin'
      : user.role === 'developer' ? '/dev'
      : '/dashboard'
    : '/login';

  return (
    <Routes>
      {/* PUBLIC */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/services" element={<Services />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/service-web"       element={<ServiceDetail serviceId="web" />} />
        <Route path="/service-ecommerce" element={<ServiceDetail serviceId="ecommerce" />} />
        <Route path="/service-branding"  element={<ServiceDetail serviceId="branding" />} />
        <Route path="/service-marketing" element={<ServiceDetail serviceId="marketing" />} />
      </Route>

      {/* AUTH */}
      <Route path="/login" element={user ? <Navigate to={defaultDashboard} replace /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to={defaultDashboard} replace /> : <Register />} />

      {/* PAYMENT */}
      <Route path="/payment/checkout/:paymentId" element={<ProtectedRoute><PaymentCheckout /></ProtectedRoute>} />
      <Route path="/payment/success/:paymentId" element={<ProtectedRoute><PaymentSuccess /></ProtectedRoute>} />
      <Route path="/payment/failure/:paymentId" element={<ProtectedRoute><PaymentFailure /></ProtectedRoute>} />
      <Route path="/payment/return" element={<ProtectedRoute><PaymentReturn /></ProtectedRoute>} />

      {/* ADMIN */}
      <Route
        path="/admin/*"
        element={
          <ProtectedRoute roles={['admin']}>
            <DashboardLayout variant="admin" />
          </ProtectedRoute>
        }
      >
        <Route index element={<AdminDashboard />} />
        <Route path="users" element={<UsersList />} />
        <Route path="users/new" element={<UserForm />} />
        <Route path="users/:id" element={<UserForm />} />
        <Route path="projects" element={<ProjectsList />} />
        <Route path="projects/new" element={<ProjectForm />} />
        <Route path="projects/:id" element={<ProjectForm />} />
        <Route path="projects/:id/view" element={<ProjectDetail />} />
        <Route path="payments" element={<AdminPaymentsList />} />
        <Route path="invoices" element={<AdminInvoicesList />} />
        <Route path="invoices/new" element={<InvoiceForm />} />
        <Route path="invoices/:id" element={<InvoiceForm />} />
        <Route path="chat" element={<ChatPage />} />
        <Route path="profile" element={<Profile />} />
      </Route>

      {/* DEVELOPER */}
      <Route
        path="/dev/*"
        element={
          <ProtectedRoute roles={['developer', 'admin']}>
            <DashboardLayout variant="developer" />
          </ProtectedRoute>
        }
      >
        <Route index element={<DeveloperDashboard />} />
        <Route path="projects" element={<DevProjectsList />} />
        <Route path="projects/:id" element={<ProjectDetail />} />
        <Route path="tasks" element={<TasksKanban />} />
        <Route path="chat" element={<ChatPage />} />
        <Route path="profile" element={<Profile />} />
      </Route>

      {/* USER */}
      <Route
        path="/dashboard/*"
        element={
          <ProtectedRoute roles={['user', 'admin']}>
            <DashboardLayout variant="user" />
          </ProtectedRoute>
        }
      >
        <Route index element={<UserDashboard />} />
        <Route path="projects" element={<UserProjectsList />} />
        <Route path="projects/new" element={<UserNewProject />} />
        <Route path="projects/:id" element={<ProjectDetail />} />
        <Route path="invoices" element={<UserInvoicesList />} />
        <Route path="payments" element={<UserPaymentsList />} />
        <Route path="chat" element={<ChatPage />} />
        <Route path="profile" element={<Profile />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
