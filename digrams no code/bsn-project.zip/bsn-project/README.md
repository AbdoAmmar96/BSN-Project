# BSN — شريك الأعمال

Full-stack web application for **شركة شريك الأعمال لتقنية المعلومات (Business Partner)** — converted from a single-file HTML SPA to a production-ready Laravel API + React SPA stack.

## 📐 Architecture

```
bsn-project/
├── api/          # Laravel 11 API (PHP 8.2+)
└── app/          # React 18 SPA (Vite + Tailwind)
```

- **Backend:** Laravel 11 + Sanctum (token-based auth) + Reverb (WebSockets)
- **Frontend:** React 18 + Vite + Tailwind + React Router + Axios + Zustand + TanStack Query
- **Database:** MySQL / MariaDB
- **Real-time:** Laravel Reverb (self-hosted WebSockets)
- **Payments:** Fawry + Paymob (Card/Wallet/Installments) + Kashier

## 👥 Three Roles

| Role | Access | Dashboard |
|------|--------|-----------|
| `admin` | كل حاجة — مستخدمين، مشاريع، مدفوعات، إعدادات | `/admin` |
| `developer` | المشاريع المسندة، المهام، التسليمات، الشات | `/dev` |
| `user` | مشاريعي، الفواتير، الدفع، الشات | `/dashboard` |

## 💳 Payment Gateways

كل بوابة بتطبّق نفس الـ `PaymentGatewayInterface` (Strategy Pattern):

```
App\Services\Payment\
  ├── PaymentGatewayInterface.php    # contract
  ├── PaymobService.php              # cards + wallets + installments
  ├── FawryService.php               # reference numbers
  ├── KashierService.php             # hosted checkout
  └── PaymentManager.php             # gateway resolver
```

## 🚀 Quick Start

شوف `SETUP.md` للخطوات التفصيلية.

```bash
# API
cd api
composer install
cp .env.example .env
php artisan key:generate
# adjust DB settings in .env then:
php artisan migrate --seed
php artisan serve

# Frontend (new terminal)
cd app
npm install
cp .env.example .env
npm run dev
```

افتح http://localhost:5173 وادخل بأي من الحسابات التجريبية (password = `password`):
- `amr@bp-eg.com` — admin
- `walid@bp-eg.com` — admin
- `dev@bp-eg.com` — developer
- `client@example.com` — user

## 📦 Project Phases

- ✅ **Phase 1 (DONE):** Foundation — auth, roles, dashboard skeletons, payment services
- 🚧 **Phase 2:** Convert public pages (services, pricing, portfolio, about, contact)
- 🚧 **Phase 3:** Dashboard CRUD (users, projects, tasks, deliverables)
- 🚧 **Phase 4:** Payment UI (gateway selector, Fawry reference display, Paymob iframe)
- 🚧 **Phase 5:** Chat (Reverb broadcasting, React UI, notifications)
- 🚧 **Phase 6:** Polish (emails, PDF invoices, file uploads, search)

## 📞 Contact

- Sales: +20 150 015 6690
- Tech: +20 106 875 8847
- Email: hello@bp-eg.com
